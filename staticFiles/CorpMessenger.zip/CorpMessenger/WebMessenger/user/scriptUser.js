function init(){ //runnnig scripts onload body

}